import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
OCR_DIR = ROOT / "ocr"
OUT = OCR_DIR / "ocr_summary.json"


def load_text(name_glob: str) -> str:
    files = sorted(OCR_DIR.glob(name_glob))
    for f in files:
        try:
            return f.read_text(encoding="utf-8")
        except Exception:
            continue
    return ""


def parse_estimate(txt: str) -> dict:
    out = {
        "vendor": None,
        "estimate_no": None,
        "date": None,
        "total": None,
        "detected_products": [],
        "interior_scope": [],
        "exterior_scope": [],
    }
    if not txt:
        return out

    # Vendor
    m_vendor = re.search(r"Karagelo\s+Projects", txt, re.IGNORECASE)
    if m_vendor:
        out["vendor"] = "Karagelo Projects"

    # Estimate number and date
    m_no = re.search(r"No:\s*(\S+)", txt)
    if m_no:
        out["estimate_no"] = m_no.group(1)
    m_date = re.search(r"Date:\s*([0-9\-\/]+)", txt)
    if m_date:
        out["date"] = m_date.group(1)

    # Total (look for Total : R ... or Sub Total/Total)
    m_total = re.search(r"Total\s*:\s*R\s*([0-9,]+)", txt)
    if m_total:
        out["total"] = f"R {m_total.group(1)}"

    # Products and scope (simple keyword heuristics)
    if re.search(r"Micatex\s*20L", txt, re.IGNORECASE):
        out["detected_products"].append("Micatex 20L")
    if re.search(r"Primer\s+solvent\s+based", txt, re.IGNORECASE):
        out["detected_products"].append("Primer solvent based")

    lines = [l.strip() for l in txt.splitlines() if l.strip()]
    for line in lines:
        low = line.lower()
        if "roof painting" in low or "waterproof" in low:
            out["exterior_scope"].append("Roof painting & waterproofing")
        if "house painting outside" in low:
            out["exterior_scope"].append("Exterior walls painting (outside)")
        if "roof material" in low:
            out["exterior_scope"].append("Roof materials")
        if "primer" in low and "crack" in low:
            out["exterior_scope"].append("Primer & crack filling")
        if "extension and inside painting" in low:
            out["interior_scope"].append("Extension & interior painting (incl. materials)")
        if "kids playroom" in low and ("wall" in low or "ceiling" in low):
            out["interior_scope"].append("Kids playroom walls & ceiling")

    # Deduplicate while preserving order
    out["detected_products"] = list(dict.fromkeys(out["detected_products"]))
    out["interior_scope"] = list(dict.fromkeys(out["interior_scope"]))
    out["exterior_scope"] = list(dict.fromkeys(out["exterior_scope"]))
    return out


def main():
    est_txt = load_text("Estimate_*.txt")
    summary = parse_estimate(est_txt)

    # Include jungle gym context if present (from DOC-*.txt)
    doc1 = load_text("DOC-*.txt")
    if doc1:
        # No paint colors here, but note kids area works for completeness
        if "jungle gym" in doc1.lower():
            extras = summary.setdefault("extras", [])
            extras.append("Kids play area/jungle gym works included on separate estimates")

    OUT.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
