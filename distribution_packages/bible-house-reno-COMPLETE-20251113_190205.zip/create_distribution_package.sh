#!/bin/bash
# Bible House Reno - Distribution Package Creator
# Creates ZIP files ready for email or web deployment

set -e  # Exit on error

PROJECT_DIR="/mnt/c/Users/LENOVO/Downloads/bible house reno"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
OUTPUT_DIR="$PROJECT_DIR/distribution_packages"

echo "📦 Creating distribution packages for Bible House Reno..."
echo ""

# Create output directory
mkdir -p "$OUTPUT_DIR"

# Package 1: Email Distribution (Small, portable)
echo "Creating EMAIL package..."
EMAIL_ZIP="$OUTPUT_DIR/bible-house-reno-EMAIL-${TIMESTAMP}.zip"

cd "$PROJECT_DIR"
zip -r "$EMAIL_ZIP" \
    "START_HERE.html" \
    "presentation/index.html" \
    "presentation/comparison.html" \
    "presentation/floorplan.drawio" \
    "presentation/palettes.svg" \
    "IMG-20251103-WA0013.jpg" \
    "IMG-20251103-WA0014.jpg" \
    "IMG-20251103-WA0015.jpg" \
    "IMG-20251103-WA0016.jpg" \
    "IMG-20251103-WA0017.jpg" \
    "IMG-20251103-WA0018.jpg" \
    "IMG-20251103-WA0019.jpg" \
    "IMG-20251103-WA0020.jpg" \
    "IMG-20251103-WA0021.jpg" \
    "IMG-20251103-WA0022.jpg" \
    "IMG-20251103-WA0023.jpg" \
    "IMG-20251103-WA0024.jpg" \
    "README.md" \
    "DISTRIBUTION_GUIDE.md" \
    "ai_prompts.yaml" \
    -x "*.pyc" "__pycache__/*" ".venv/*" \
    > /dev/null 2>&1

echo "✅ Email package created: $(basename $EMAIL_ZIP)"
echo "   Size: $(du -h "$EMAIL_ZIP" | cut -f1)"

# Package 2: Web Deployment (Optimized for hosting)
echo ""
echo "Creating WEB deployment package..."
WEB_ZIP="$OUTPUT_DIR/bible-house-reno-WEB-${TIMESTAMP}.zip"

cd "$PROJECT_DIR"
zip -r "$WEB_ZIP" \
    "presentation/" \
    "IMG-20251103-WA00*.jpg" \
    "START_HERE.html" \
    ".nojekyll" \
    -x "*.pyc" "__pycache__/*" ".venv/*" "*.pdf" \
    > /dev/null 2>&1 || true  # Continue even if .nojekyll doesn't exist

echo "✅ Web package created: $(basename $WEB_ZIP)"
echo "   Size: $(du -h "$WEB_ZIP" | cut -f1)"

# Package 3: Complete Archive (Everything for backup)
echo ""
echo "Creating COMPLETE backup archive..."
COMPLETE_ZIP="$OUTPUT_DIR/bible-house-reno-COMPLETE-${TIMESTAMP}.zip"

cd "$PROJECT_DIR"
zip -r "$COMPLETE_ZIP" \
    . \
    -x ".venv/*" "__pycache__/*" "*.pyc" "ocr/*" "distribution_packages/*" \
    > /dev/null 2>&1

echo "✅ Complete archive created: $(basename $COMPLETE_ZIP)"
echo "   Size: $(du -h "$COMPLETE_ZIP" | cut -f1)"

# Create README for recipients
echo ""
echo "Creating README for team..."
cat > "$OUTPUT_DIR/README_FOR_TEAM.txt" << 'EOF'
========================================
BIBLE HOUSE RENOVATION - INTERACTIVE PRESENTATION
Estimate #40 | R 95,600 | 26 October 2025
========================================

WHAT'S INCLUDED:
- Interactive web presentations (HTML)
- 12 room photos
- 3 professional color palettes
- Floor plan diagram
- AI repaint prompts

HOW TO USE:
1. Extract this ZIP file to your computer
2. Double-click "START_HERE.html"
3. Your browser will open with a menu
4. Click any presentation to view

FEATURES:
✓ Works offline (no internet needed)
✓ View on any computer (Windows/Mac/Linux)
✓ Interactive color palette comparisons
✓ Copy-paste ready AI prompts
✓ Professional floor plan diagram

PRESENTATIONS INCLUDED:
1. Main Gallery - All rooms with color options
2. Comparison Tool - Before/after template
3. Floor Plan - Renovation scope diagram
4. Color Palettes - Professional swatches

TECHNICAL REQUIREMENTS:
- Any modern web browser (Chrome, Firefox, Edge, Safari)
- No installation needed
- No plugins required

FOR QUESTIONS:
Contact the project creator or refer to README.md

---
Created with VS Code + Live Server + AI Tools
Bible House Reno Interactive Presentation System
EOF

echo "✅ README created: README_FOR_TEAM.txt"

# Create deployment instructions for web hosting
cat > "$OUTPUT_DIR/WEB_DEPLOYMENT_INSTRUCTIONS.txt" << 'EOF'
========================================
WEB DEPLOYMENT INSTRUCTIONS
Bible House Reno Presentation
========================================

OPTION 1: NETLIFY (EASIEST)
----------------------------
1. Go to https://app.netlify.com/drop
2. Drag the extracted folder onto the page
3. Get instant URL (e.g., https://random-name.netlify.app)
4. Share URL with team
5. (Optional) Set custom domain in settings

OPTION 2: GITHUB PAGES
----------------------
1. Create GitHub repository
2. Upload files to repository
3. Go to Settings > Pages
4. Select branch: main, folder: / (root)
5. Access at: https://yourusername.github.io/repo-name

OPTION 3: VERCEL
----------------
1. Install Vercel CLI: npm install -g vercel
2. Navigate to extracted folder
3. Run: vercel
4. Follow prompts
5. Get URL: https://project-name.vercel.app

OPTION 4: GOOGLE DRIVE / DROPBOX
---------------------------------
1. Upload folder to cloud storage
2. Set sharing to "Anyone with link"
3. Share folder link with team
4. Team opens index.html from shared folder
   ⚠️ Note: Some interactive features may not work

CUSTOM DOMAIN SETUP:
--------------------
All platforms above support custom domains
Example: https://biblehouse.yourcompany.com

For custom domains:
1. Add CNAME record in DNS settings
2. Point to hosting provider
3. Configure in hosting platform settings
4. Wait 24-48 hours for propagation

RECOMMENDED: Netlify or Vercel for best experience
EOF

echo "✅ Web deployment instructions created"

# Summary
echo ""
echo "========================================="
echo "📦 PACKAGING COMPLETE!"
echo "========================================="
echo ""
echo "Created in: $OUTPUT_DIR"
echo ""
echo "FILES CREATED:"
echo "  1. $(basename $EMAIL_ZIP) - For email distribution"
echo "  2. $(basename $WEB_ZIP) - For web hosting"
echo "  3. $(basename $COMPLETE_ZIP) - Complete backup"
echo "  4. README_FOR_TEAM.txt - Instructions for recipients"
echo "  5. WEB_DEPLOYMENT_INSTRUCTIONS.txt - Hosting guide"
echo ""
echo "NEXT STEPS:"
echo "  📧 Email: Attach $(basename $EMAIL_ZIP) to email"
echo "  🌐 Web: Deploy $(basename $WEB_ZIP) to Netlify/Vercel"
echo "  💾 Backup: Keep $(basename $COMPLETE_ZIP) safe"
echo ""
echo "WINDOWS PATH:"
echo "  C:\\Users\\LENOVO\\Downloads\\bible house reno\\distribution_packages\\"
echo ""
echo "========================================="
