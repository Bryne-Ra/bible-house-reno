import os
import json
import io
import shutil
from pathlib import Path
from typing import List, Optional

from PIL import Image
from pypdf import PdfReader

# Optional backends (import gracefully)
try:
    import fitz  # PyMuPDF
except Exception:
    fitz = None

try:
    import easyocr  # DL-based OCR, no system tesseract required
except Exception:
    easyocr = None

try:
    import pytesseract  # If system tesseract is available
except Exception:
    pytesseract = None

ROOT = Path(__file__).resolve().parent
INCLUDE_GLOBS = [
    "DOC-*.pdf",
    "Estimate_*.pdf",
    "scan_*.pdf",
]
OUT_DIR = ROOT / "ocr"
OUT_DIR.mkdir(exist_ok=True)


def try_text_extract(pdf_path: Path) -> str:
    """Try to extract embedded text using pypdf first."""
    try:
        reader = PdfReader(str(pdf_path))
        texts = []
        for page in reader.pages:
            t = page.extract_text() or ""
            texts.append(t)
        return "\n".join(texts).strip()
    except Exception:
        return ""

def _ocr_with_easyocr(img: Image.Image, lang_list: Optional[List[str]] = None) -> Optional[str]:
    """OCR using EasyOCR if available."""
    if easyocr is None:
        return None
    if lang_list is None:
        lang_list = ["en"]
    # Lazy-init singleton reader
    if not hasattr(_ocr_with_easyocr, "_reader"):
        _ocr_with_easyocr._reader = easyocr.Reader(lang_list, gpu=False)
    reader = _ocr_with_easyocr._reader
    import numpy as np
    arr = np.array(img.convert("RGB"))
    result = reader.readtext(arr, detail=0, paragraph=True)
    return "\n".join(result).strip()


def _ocr_with_tesseract(img: Image.Image, lang: str = "eng") -> Optional[str]:
    """OCR using pytesseract if tesseract binary is available."""
    if pytesseract is None:
        return None
    if shutil.which("tesseract") is None:
        return None
    return pytesseract.image_to_string(img, lang=lang).strip()


def rasterize_pdf_pages(pdf_path: Path, zoom: float = 2.0) -> List[Image.Image]:
    """Render PDF pages to PIL Images using PyMuPDF (fitz) to avoid poppler dependency."""
    if fitz is None:
        raise RuntimeError("PyMuPDF (pymupdf) not installed. Run: pip install pymupdf")
    images: List[Image.Image] = []
    doc = fitz.open(str(pdf_path))
    mat = fitz.Matrix(zoom, zoom)
    for page in doc:
        pix = page.get_pixmap(matrix=mat, alpha=False)
        pil = Image.open(io.BytesIO(pix.tobytes("png"))).convert("RGB")
        images.append(pil)
    return images


def ocr_pdf(pdf_path: Path, lang: str = "eng") -> List[str]:
    """OCR each page by rendering via PyMuPDF, then using EasyOCR (preferred) or Tesseract."""
    imgs = rasterize_pdf_pages(pdf_path, zoom=2.0)
    page_texts: List[str] = []
    for img in imgs:
        text = _ocr_with_easyocr(img, ["en"]) or _ocr_with_tesseract(img, lang) or ""
        page_texts.append(text.strip())
    return page_texts


def process_pdf(pdf_path: Path):
    base = pdf_path.stem
    txt_out = OUT_DIR / f"{base}.txt"
    json_out = OUT_DIR / f"{base}.json"

    # 1) Try embedded text
    embedded = try_text_extract(pdf_path)
    if embedded and embedded.strip():
        all_text = embedded
        pages = [embedded]
        source = "embedded"
    else:
        # 2) Fall back to OCR
        try:
            pages = ocr_pdf(pdf_path)
            all_text = "\n\n".join(pages)
            source = "ocr"
        except Exception as e:
            all_text = f"[OCR failed: {e}]"
            pages = [all_text]
            source = "error"

    txt_out.write_text(all_text, encoding="utf-8")
    json_out.write_text(
        json.dumps({
            "file": str(pdf_path),
            "source": source,
            "pages": pages,
        }, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Processed {pdf_path.name} -> {txt_out.name} [{source}]")


def main():
    pdfs = []
    for pat in INCLUDE_GLOBS:
        pdfs.extend(ROOT.glob(pat))
    if not pdfs:
        print("No PDFs matched.")
        return

    for pdf in sorted(pdfs):
        process_pdf(pdf)


if __name__ == "__main__":
    main()
