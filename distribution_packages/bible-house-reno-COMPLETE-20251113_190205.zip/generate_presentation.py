import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_THEME_COLOR
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE
from PIL import Image
import yaml

FOLDER = os.path.dirname(__file__)
PROMPTS_PATH = os.path.join(FOLDER, "ai_prompts.yaml")
OUTPUT_PPTX = os.path.join(FOLDER, "Bible_House_Reno_Paint_Concepts.pptx")
OCR_SUMMARY_JSON = os.path.join(FOLDER, "ocr", "ocr_summary.json")

SLIDE_W = Inches(13.33)
SLIDE_H = Inches(7.5)

# Simple helper to fit an image into a bounding box while preserving aspect
def fit_image(image_path, max_w_in, max_h_in):
    with Image.open(image_path) as im:
        w, h = im.size
        dpi = im.info.get("dpi", (96, 96))[0]
        # Convert target size from inches to pixels (@96 DPI fallback)
        px_per_in = dpi if dpi and dpi > 10 else 96
        max_w_px = int(max_w_in * px_per_in)
        max_h_px = int(max_h_in * px_per_in)
        scale = min(max_w_px / w, max_h_px / h)
        new_w, new_h = int(w * scale), int(h * scale)
        return new_w, new_h


def add_title_slide(prs: Presentation):
    slide_layout = prs.slide_layouts[0]  # Title slide
    slide = prs.slides.add_slide(slide_layout)
    slide.shapes.title.text = "Bible House Renovation"
    subtitle = slide.placeholders[1]
    subtitle.text = "Paint Concepts — AI Visualizations"
    return slide

def add_summary_slide(prs: Presentation, summary: dict):
    slide_layout = prs.slide_layouts[1]  # Title and Content
    slide = prs.slides.add_slide(slide_layout)
    slide.shapes.title.text = "Estimate Summary"
    body = slide.placeholders[1].text_frame
    body.clear()

    vendor = summary.get("vendor")
    estimate_no = summary.get("estimate_no")
    date = summary.get("date")
    total = summary.get("total")
    detected_products = summary.get("detected_products", [])
    interior = summary.get("interior_scope", [])
    exterior = summary.get("exterior_scope", [])

    p = body.paragraphs[0]
    p.text = f"Vendor: {vendor} | Estimate #{estimate_no} | Date: {date} | Total: {total}"
    p.level = 0
    p.font.size = Pt(14)

    if detected_products:
        p2 = body.add_paragraph()
        p2.text = "Products: " + ", ".join(detected_products)
        p2.level = 0

    if interior:
        p3 = body.add_paragraph()
        p3.text = "Interior scope:"
        p3.level = 0
        for it in interior:
            b = body.add_paragraph()
            b.text = f"- {it}"
            b.level = 1

    if exterior:
        p4 = body.add_paragraph()
        p4.text = "Exterior scope:"
        p4.level = 0
        for it in exterior:
            b = body.add_paragraph()
            b.text = f"- {it}"
            b.level = 1

    return slide


def add_image_slide(prs: Presentation, image_path: str, prompts: list, palettes: dict, common: dict):
    slide_layout = prs.slide_layouts[6]  # blank
    slide = prs.slides.add_slide(slide_layout)

    # Title box at top
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.2), Inches(12.33), Inches(0.6))
    title_tf = title_box.text_frame
    title_tf.text = os.path.basename(image_path)
    title_tf.paragraphs[0].font.size = Pt(24)
    title_tf.paragraphs[0].font.bold = True

    # Left: original image
    left_x = Inches(0.5)
    left_y = Inches(1.0)
    left_w = Inches(6.0)
    left_h = Inches(5.0)

    if os.path.exists(image_path):
        # scale image to fit box; pptx will scale but we size roughly
        w_px, h_px = fit_image(image_path, 6.0, 5.0)
        pic = slide.shapes.add_picture(image_path, left_x, left_y, width=Inches(6.0))
    else:
        ph = slide.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.RECTANGLE, left_x, left_y, left_w, left_h)
        ph.text_frame.text = "Original image not found"

    # Right: placeholder for AI-edited image
    right_x = Inches(6.9)
    right_y = Inches(1.0)
    right_w = Inches(6.0)
    right_h = Inches(5.0)

    ph = slide.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.RECTANGLE, right_x, right_y, right_w, right_h)
    fill = ph.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(240, 240, 240)
    line = ph.line
    line.color.rgb = RGBColor(200, 200, 200)
    tf = ph.text_frame
    tf.text = "Insert AI-edited image here"
    tf.paragraphs[0].alignment = PP_ALIGN.CENTER
    tf.paragraphs[0].font.size = Pt(14)

    # Prompts box below
    box_x = Inches(0.5)
    box_y = Inches(6.2)
    box_w = Inches(12.3)
    box_h = Inches(1.1)
    prompt_box = slide.shapes.add_textbox(box_x, box_y, box_w, box_h)
    tf2 = prompt_box.text_frame
    tf2.clear()

    # Add up to three prompt variants
    for idx, p in enumerate(prompts[:3], start=1):
        pal_key = p.get("palette")
        pal = palettes.get(pal_key, {})
        bullet = tf2.add_paragraph() if len(tf2.paragraphs) > 0 else tf2.paragraphs[0]
        bullet.text = f"{idx}. {pal.get('name', pal_key)} — {p.get('text','').strip()}"
        bullet.level = 0
        bullet.font.size = Pt(12)

    # Add negative prompt / constraints
    neg = common.get("negative_prompt")
    if neg:
        pneg = tf2.add_paragraph()
        pneg.text = f"Negative prompt: {neg}"
        pneg.level = 0
        pneg.font.size = Pt(10)
        pneg.font.italic = True

    return slide


def main():
    with open(PROMPTS_PATH, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    palettes = data.get("palettes", {})
    common = data.get("common", {})
    images = data.get("images", [])

    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H

    add_title_slide(prs)

    # If an OCR summary exists, insert a summary slide
    if os.path.exists(OCR_SUMMARY_JSON):
        try:
            import json
            with open(OCR_SUMMARY_JSON, "r", encoding="utf-8") as jf:
                summary = json.load(jf)
            add_summary_slide(prs, summary)
        except Exception as e:
            pass

    for item in images:
        img_path = os.path.join(FOLDER, item["file"])
        prompts = item.get("prompts", [])
        add_image_slide(prs, img_path, prompts, palettes, common)

    prs.save(OUTPUT_PPTX)
    print(f"Saved: {OUTPUT_PPTX}")


if __name__ == "__main__":
    main()
