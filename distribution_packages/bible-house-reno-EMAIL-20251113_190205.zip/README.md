# Bible House Renovation – Interactive AI Paint Concepts 🏠# Bible House Renovation – AI Paint Concepts



This project provides a **complete interactive renovation presentation system** with OCR-extracted estimates, AI repaint prompts, professional web presentations, and visual planning tools.This folder contains your site photos, estimates, OCR outputs, and an auto-generated presentation to showcase AI-powered paint concepts.



## 📦 What's Included## 📦 What's Included



### PowerPoint Presentation### PowerPoint Presentation

- `Bible_House_Reno_Paint_Concepts.pptx` – Professional PPTX with:

- `Bible_House_Reno_Paint_Concepts.pptx` – Professional PPTX with:  - Title slide and "Estimate Summary" (extracted via OCR)

  - Title slide and "Estimate Summary" (extracted via OCR)  - Per-photo slides: original image, placeholder for AI-generated "after", and palette-specific prompts

  - Per-photo slides: original image, placeholder for AI-generated "after", and palette-specific prompts

### 🌟 NEW: Interactive Web Presentation

### 🌟 NEW: Interactive Web Presentation- **`presentation/index.html`** – Main interactive gallery with color palettes, room transformations, and copyable AI prompts

- **`presentation/comparison.html`** – Before/after slider comparison tool (template for AI-generated images)

- **`presentation/index.html`** – Main interactive gallery with color palettes, room transformations, and copyable AI prompts- **`presentation/floorplan.drawio`** – Color-coded floor plan showing renovation scope (open with Draw.io VS Code extension)

- **`presentation/comparison.html`** – Before/after slider comparison tool (template for AI-generated images)- **`presentation/palettes.svg`** – Professional SVG color swatches with hex codes and finish specifications

- **`presentation/floorplan.drawio`** – Color-coded floor plan showing renovation scope (open with Draw.io VS Code extension)

- **`presentation/palettes.svg`** – Professional SVG color swatches with hex codes and finish specifications### Core Data & Scripts

- `ai_prompts.yaml` – AI repaint prompts across 3 palettes (Warm Neutral, Modern Gray, Earthy Olive) + detected materials

### Core Data & Scripts- `assumptions.md` – Paint scope assumptions and finish specifications

- `ocr/` – OCR outputs (`*.txt`, `*.json`) + `ocr_summary.json` (parsed estimate data)

- `ai_prompts.yaml` – AI repaint prompts across 3 palettes (Warm Neutral, Modern Gray, Earthy Olive) + detected materials- `ocr_extract.py` – OCR pipeline (PyMuPDF + EasyOCR)

- `assumptions.md` – Paint scope assumptions and finish specifications- `parse_ocr.py` – Parses OCR into structured JSON summary

- `ocr/` – OCR outputs (`*.txt`, `*.json`) + `ocr_summary.json` (parsed estimate data)- `generate_presentation.py` – Builds the PPTX from YAML data

- `ocr_extract.py` – OCR pipeline (PyMuPDF + EasyOCR)- `IMG-*.jpg` – Original "before" photos

- `parse_ocr.py` – Parses OCR into structured JSON summary

- `generate_presentation.py` – Builds the PPTX from YAML data## Quick start

- `IMG-*.jpg` – Original "before" photos

1. Generate/refresh the OCR summary (WSL):

## 🚀 Quick Start

```bash

### Option 1: View the Interactive Web Presentation (Recommended)cd "/mnt/c/Users/LENOVO/Downloads/bible house reno"

python3 -m venv .venv

1. **Right-click** `presentation/index.html` in VS Code. .venv/bin/activate

2. Select **"Open with Live Server"** or **"Open in Simple Browser"**pip install --upgrade pip setuptools wheel

3. Browse the interactive gallery with all three color palettes and copyable AI prompts# Option A (no sudo, larger):

4. View the color palette visualization: open `presentation/palettes.svg`pip install easyocr pymupdf pillow pypdf tqdm

5. Open the floor plan: `presentation/floorplan.drawio` (requires Draw.io extension)python ocr_extract.py

python parse_ocr.py

### Option 2: Regenerate OCR Summary & PowerPoint```



#### Step 1: Update OCR data (WSL)2. Rebuild the presentation (Windows Python):



```bash```bash

cd "/mnt/c/Users/LENOVO/Downloads/bible house reno"/mnt/c/Users/LENOVO/anaconda3/Scripts/conda.exe run -n base python "C:\\Users\\LENOVO\\Downloads\\bible house reno\\generate_presentation.py"

python3 -m venv .venv```

. .venv/bin/activate

pip install --upgrade pip setuptools wheelThe PPTX will be saved as `Bible_House_Reno_Paint_Concepts.pptx`.

pip install easyocr pymupdf pillow pypdf tqdm

python ocr_extract.py## Create AI "after" images

python parse_ocr.py

```Use your preferred AI tool (Microsoft Designer, Copilot Designer, Adobe Firefly, Stable Diffusion, etc.). For each room photo:



#### Step 2: Rebuild PowerPoint (Windows Python)1. Upload the original image (e.g., `IMG-20251103-WA0013.jpg`).

2. Mask only the walls (and trims/ceiling if specified).

```bash3. Paste one of the prompts from `ai_prompts.yaml` (the same prompts are shown on each slide).

/mnt/c/Users/LENOVO/anaconda3/Scripts/conda.exe run -n base python "C:\\Users\\LENOVO\\Downloads\\bible house reno\\generate_presentation.py"4. Export the edited image and drop it into the right-hand placeholder on the slide.

```

Notes:

The PPTX will be saved as `Bible_House_Reno_Paint_Concepts.pptx`.- Finishes: walls = matte/eggshell, ceiling = flat, trims/doors = satin/semigloss

- Negative prompt is included to avoid changing floors, windows, furniture, or lighting

## 🎨 Create AI "After" Images

## Materials detected (from OCR)

Use your preferred AI tool (Microsoft Designer, Copilot Designer, Adobe Firefly, Midjourney, Stable Diffusion). For each room photo:

- Micatex 20L (exterior)

1. **Upload** the original image (e.g., `IMG-20251103-WA0013.jpg`)- Primer (solvent-based) & crack filling

2. **Mask** only the walls (and trims/ceiling if specified)

3. **Copy & paste** one of the prompts from `presentation/index.html` or `ai_prompts.yaml`If you have exact paint brand/color names (e.g., for interior walls and trims), update `ai_prompts.yaml` with those codes and re-run the deck generator.

4. **Generate** the AI repaint

5. **Save** the result to `presentation/after/` folder (create if needed)## Troubleshooting

6. **Update** `presentation/comparison.html` to show before/after sliders

- EasyOCR install downloads PyTorch (~600MB). If you prefer a smaller setup, install Tesseract + Poppler in WSL and I can switch the OCR pipeline accordingly.

### Palette Options- If the deck fails to build on Windows, ensure `python-pptx` is installed in that environment.



- 🌾 **Warm Neutral**: Walls #E8DCC8, Trim #FFFFFF, Ceiling #F7F7F7## Next steps

- 🏢 **Modern Gray + Navy**: Walls #E6E9ED, Accent #1F3A5F, Trim #FFFFFF

- 🌿 **Earthy Olive**: Walls #D9C5A1, Accent #5A6A4F, Trim #FFFFFF- Provide exact interior color codes/brand to finalize prompts and a "Final Colors" deck

- Add an exterior-focused deck showing Micatex color options on exterior photos (if available)

### Paint Finishes- Optional: organize files into `docs/`, `photos/`, `slides/`, `ocr/`, `ai-edits/` and add a cost breakdown slide from the estimate


- Walls: matte/eggshell
- Ceiling: flat
- Trims/doors: satin/semi-gloss
- Negative prompt included to preserve floors, windows, furniture, and lighting

## 📊 Estimate Details (OCR Extracted)

- **Estimate #**: 40
- **Date**: 26 October 2025
- **Total**: R 95,600
- **Scope**: Interior + Exterior + Roof + Kids Playroom

### Materials Detected

- Micatex 20L (exterior)
- Primer (solvent-based) & crack filling

## 🛠️ Recommended VS Code Extensions

These extensions enhance the presentation experience:

- **Live Server** (`ritwickdey.liveserver`) – Preview HTML presentations with auto-reload
- **Draw.io Integration** (`hediet.vscode-drawio`) – View and edit the floor plan
- **SVG Preview** (`simonsiefke.svg-preview`) – Preview color palette SVG
- **Image Comparison Slider** (`paulmesseant.imageslider`) – For before/after comparisons
- **glTF Tools** (`cesium.gltf-vscode`) – If you add 3D models later

Install via: Extensions → Search → Install

## 📁 Recommended File Organization

Once you generate AI images, organize like this:

```
bible house reno/
├── presentation/
│   ├── index.html (main gallery)
│   ├── comparison.html (before/after tool)
│   ├── floorplan.drawio
│   ├── palettes.svg
│   └── after/ (create this folder)
│       ├── IMG-20251103-WA0013_warm_neutral.jpg
│       ├── IMG-20251103-WA0013_modern_gray.jpg
│       └── ... (AI-generated images)
├── IMG-*.jpg (original photos)
├── ai_prompts.yaml
├── Bible_House_Reno_Paint_Concepts.pptx
└── README.md (this file)
```

## 🎯 Next Steps

### Immediate Actions

1. **Review** the interactive web presentation (`presentation/index.html`)
2. **Generate AI images** using the prompts for your preferred palette
3. **Update** comparison.html with actual before/after images
4. **Present** to client using Live Server

### Future Enhancements

- Provide exact interior paint brand/color codes to finalize prompts
- Add exterior-focused deck with Micatex color options
- Create cost breakdown slides from the estimate
- Add 3D room mockups or AR previews (if needed)
- Integrate client feedback system

## 🐛 Troubleshooting

### OCR Issues

- EasyOCR downloads PyTorch (~600MB). For smaller setup, install Tesseract + Poppler in WSL
- If OCR fails, ensure PDFs are in the root folder

### PowerPoint Issues

- Ensure `python-pptx` is installed: `pip install python-pptx`
- Check that YAML file is valid (no syntax errors)

### Web Presentation Issues

- If Live Server doesn't work, try "Open with Simple Browser"
- For image paths, ensure relative paths are correct (`../IMG-*.jpg`)
- Check browser console (F12) for JavaScript errors

## 📞 Support

For questions about:

- **AI image generation**: Refer to your AI tool's documentation (Microsoft Designer, Adobe Firefly, etc.)
- **Color customization**: Edit `ai_prompts.yaml` and regenerate
- **Floor plan edits**: Open `presentation/floorplan.drawio` in Draw.io extension

---

**Pro Tip**: Use the web presentation for client meetings – it's interactive, professional, and easier to navigate than PowerPoint for color comparison discussions!
