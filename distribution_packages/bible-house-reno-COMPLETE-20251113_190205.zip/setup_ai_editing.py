"""
Bible House Reno - AI Image Editor (Semi-Automated)
Generates "after" images using AI repaint prompts

This script prepares images and prompts for AI editing services.
Choose your method:
1. Export prompts for manual editing (Microsoft Designer, Adobe Firefly)
2. Use Replicate API for automated processing (requires API key)
3. Use Stability AI (Stable Diffusion) API (requires API key)
"""

import os
import yaml
import json
import base64
from pathlib import Path
from typing import Dict, List

# Project paths
PROJECT_ROOT = Path(__file__).parent
IMAGES_DIR = PROJECT_ROOT
PROMPTS_FILE = PROJECT_ROOT / "ai_prompts.yaml"
OUTPUT_DIR = PROJECT_ROOT / "presentation" / "after"
BATCH_DIR = PROJECT_ROOT / "ai_editing_batch"

def load_prompts() -> Dict:
    """Load AI prompts from YAML file"""
    with open(PROMPTS_FILE, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def create_manual_editing_package():
    """
    Create organized folders with images and prompts for manual AI editing
    Perfect for Microsoft Designer, Adobe Firefly, or Midjourney
    """
    print("📦 Creating manual editing package...")
    
    # Create output structure
    for palette in ['warm_neutral', 'modern_gray', 'earthy_olive']:
        palette_dir = BATCH_DIR / palette
        palette_dir.mkdir(parents=True, exist_ok=True)
    
    # Load prompts
    data = load_prompts()
    
    # Create instruction files for each palette
    for palette_key, palette_info in data['palettes'].items():
        palette_dir = BATCH_DIR / palette_key
        
        # Create palette info file
        palette_readme = palette_dir / "PALETTE_INFO.txt"
        with open(palette_readme, 'w', encoding='utf-8') as f:
            f.write(f"{'='*60}\n")
            f.write(f"{palette_info['name'].upper()}\n")
            f.write(f"{'='*60}\n\n")
            f.write(f"Walls:   {palette_info['walls_hex']}\n")
            f.write(f"Ceiling: {palette_info['ceiling_hex']}\n")
            f.write(f"Trim:    {palette_info['trim_hex']}\n")
            if palette_info.get('accent_hex'):
                f.write(f"Accent:  {palette_info['accent_hex']}\n")
            f.write(f"\n{'='*60}\n\n")
            
            f.write("FINISHES:\n")
            f.write(f"- Walls: {data['common']['finish']['walls']}\n")
            f.write(f"- Ceiling: {data['common']['finish']['ceiling']}\n")
            f.write(f"- Trim: {data['common']['finish']['trim']}\n")
            f.write(f"\n{'='*60}\n\n")
            
            f.write("NEGATIVE PROMPT:\n")
            f.write(f"{data['common']['negative_prompt']}\n")
            f.write(f"\n{'='*60}\n\n")
    
    # Create per-image prompt files
    for image_data in data['images']:
        image_file = image_data['file']
        image_path = IMAGES_DIR / image_file
        
        if not image_path.exists():
            print(f"⚠️  Image not found: {image_file}")
            continue
        
        image_name = image_path.stem
        
        for prompt_data in image_data['prompts']:
            palette = prompt_data['palette']
            prompt_text = prompt_data['text']
            
            palette_dir = BATCH_DIR / palette
            
            # Copy image to palette folder
            target_image = palette_dir / f"{image_name}.jpg"
            if not target_image.exists():
                import shutil
                shutil.copy(image_path, target_image)
            
            # Create prompt file
            prompt_file = palette_dir / f"{image_name}_PROMPT.txt"
            with open(prompt_file, 'w', encoding='utf-8') as f:
                f.write(f"IMAGE: {image_file}\n")
                f.write(f"PALETTE: {data['palettes'][palette]['name']}\n")
                f.write(f"\n{'='*60}\n")
                f.write("AI REPAINT PROMPT:\n")
                f.write(f"{'='*60}\n\n")
                f.write(prompt_text.strip())
                f.write(f"\n\n{'='*60}\n")
                f.write("NEGATIVE PROMPT:\n")
                f.write(f"{'='*60}\n\n")
                f.write(data['common']['negative_prompt'])
                f.write(f"\n\n{'='*60}\n")
                f.write("\nINSTRUCTIONS:\n")
                f.write("1. Upload this image to your AI tool\n")
                f.write("2. Use inpainting/masking to select walls & trim\n")
                f.write("3. Paste the prompt above\n")
                f.write("4. Add negative prompt if supported\n")
                f.write("5. Generate and save as: {}_after.jpg\n".format(image_name))
    
    print(f"✅ Manual editing package created in: {BATCH_DIR}")
    print(f"\nFolders created:")
    print(f"  - warm_neutral/    (12 images + prompts)")
    print(f"  - modern_gray/     (12 images + prompts)")
    print(f"  - earthy_olive/    (12 images + prompts)")
    print(f"\nNext steps:")
    print(f"  1. Open each folder")
    print(f"  2. For each image, open the corresponding _PROMPT.txt")
    print(f"  3. Upload image to AI tool (Microsoft Designer, Adobe Firefly)")
    print(f"  4. Copy-paste the prompt")
    print(f"  5. Save result as: IMAGENAME_after.jpg")

def create_api_batch_json():
    """
    Create JSON batch file for API-based processing
    Compatible with Replicate, Stability AI, or custom API
    """
    print("📄 Creating API batch configuration...")
    
    data = load_prompts()
    batch_config = {
        "project": "Bible House Reno",
        "estimate": "40",
        "total_jobs": 0,
        "palettes": {},
        "jobs": []
    }
    
    # Add palette info
    for palette_key, palette_info in data['palettes'].items():
        batch_config["palettes"][palette_key] = {
            "name": palette_info['name'],
            "colors": {
                "walls": palette_info['walls_hex'],
                "ceiling": palette_info['ceiling_hex'],
                "trim": palette_info['trim_hex'],
                "accent": palette_info.get('accent_hex')
            }
        }
    
    # Create jobs
    job_id = 1
    for image_data in data['images']:
        image_file = image_data['file']
        image_path = IMAGES_DIR / image_file
        
        if not image_path.exists():
            continue
        
        for prompt_data in image_data['prompts']:
            palette = prompt_data['palette']
            prompt_text = prompt_data['text']
            
            job = {
                "job_id": job_id,
                "input_image": str(image_path),
                "palette": palette,
                "prompt": prompt_text.strip(),
                "negative_prompt": data['common']['negative_prompt'],
                "output_filename": f"{image_path.stem}_{palette}_after.jpg",
                "parameters": {
                    "strength": 0.7,
                    "guidance_scale": 7.5,
                    "num_inference_steps": 50
                }
            }
            
            batch_config["jobs"].append(job)
            job_id += 1
    
    batch_config["total_jobs"] = len(batch_config["jobs"])
    
    # Save batch config
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    batch_file = OUTPUT_DIR / "api_batch_config.json"
    
    with open(batch_file, 'w', encoding='utf-8') as f:
        json.dump(batch_config, f, indent=2)
    
    print(f"✅ API batch config created: {batch_file}")
    print(f"   Total jobs: {batch_config['total_jobs']}")
    print(f"\nTo process with API:")
    print(f"  1. Get API key from Replicate.com or Stability AI")
    print(f"  2. Run: python process_api_batch.py")
    print(f"  3. Edited images saved to: {OUTPUT_DIR}")

def export_for_comparison_html():
    """
    Create template for updating comparison.html with before/after pairs
    """
    print("📝 Creating comparison.html update template...")
    
    data = load_prompts()
    template = []
    
    template.append("<!-- Copy this into comparison.html -->")
    template.append("<!-- Replace the placeholder sections with these cards -->\n")
    
    for i, image_data in enumerate(data['images'][:3], 1):  # First 3 rooms as examples
        image_file = image_data['file']
        room_name = f"Room {i}"
        
        for prompt_data in image_data['prompts']:
            palette = prompt_data['palette']
            palette_info = data['palettes'][palette]
            
            template.append(f"""
<div class="comparison-card">
    <h3>{room_name} - {palette_info['name']}</h3>
    <div class="image-comparison">
        <img src="../{image_file}" class="image-before" alt="Before">
        <img src="after/{image_data['file'].replace('.jpg', f'_{palette}_after.jpg')}" class="image-after" alt="After">
        <div class="slider-control"></div>
    </div>
    <div class="labels">
        <span class="label-before">← BEFORE</span>
        <span class="label-after">AFTER →</span>
    </div>
    <div class="palette-info">
        <strong>Palette:</strong> {palette_info['name']}<br>
        <strong>Walls:</strong> {palette_info['walls_hex']} | <strong>Trim:</strong> {palette_info['trim_hex']}
    </div>
</div>
""")
    
    template_file = OUTPUT_DIR / "comparison_html_template.html"
    with open(template_file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(template))
    
    print(f"✅ Template created: {template_file}")
    print(f"   Copy contents into presentation/comparison.html")

def main():
    """Main execution"""
    print("\n" + "="*60)
    print("BIBLE HOUSE RENO - AI IMAGE EDITING SETUP")
    print("="*60 + "\n")
    
    print("Choose editing method:")
    print("  1. Manual editing package (Microsoft Designer, Adobe Firefly)")
    print("  2. API batch config (Replicate, Stability AI)")
    print("  3. Both")
    print("  4. Exit")
    
    choice = input("\nEnter choice (1-4): ").strip()
    
    if choice == "1" or choice == "3":
        create_manual_editing_package()
        print()
    
    if choice == "2" or choice == "3":
        create_api_batch_json()
        print()
    
    if choice in ["1", "2", "3"]:
        export_for_comparison_html()
        print("\n" + "="*60)
        print("✅ SETUP COMPLETE!")
        print("="*60)
        print(f"\nFiles created in:")
        print(f"  - {BATCH_DIR} (manual editing)")
        print(f"  - {OUTPUT_DIR} (API configs)")
        print(f"\nWindows path:")
        print(f"  C:\\Users\\LENOVO\\Downloads\\bible house reno\\ai_editing_batch\\")
    
    elif choice == "4":
        print("Exiting...")
    else:
        print("Invalid choice!")

if __name__ == "__main__":
    main()
