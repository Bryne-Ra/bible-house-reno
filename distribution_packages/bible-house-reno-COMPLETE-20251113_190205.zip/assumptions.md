# Paint Renovation Assumptions (for AI image edits)

Because the estimate and doc PDFs are image-only scans and not directly machine-readable, we make these pragmatic assumptions aligned with typical interior repaint scopes:

- Scope: Interior repaint of walls, ceilings (selectively), and trims/doors; no changes to floors, windows, or built-ins.
- Finish: Matte (eggshell) on walls, flat on ceilings, satin/semigloss on trims and doors.
- Palettes to explore (can be swapped to your brand-specific colors later):
  - Warm Neutral: walls #E8DCC8 (warm beige), trim/doors #FFFFFF (pure white), ceiling #F7F7F7 (soft white).
  - Modern Gray: walls #E6E9ED (light gray), trim/doors #FFFFFF, ceiling #F7F7F7; accent wall #1F3A5F (deep navy) optional.
  - Earthy Olive: walls #D9C5A1 (light khaki), trim/doors #FFFFFF, ceiling #F7F7F7; accent #5A6A4F (muted olive).
- Constraints: Preserve existing architecture, fixtures, windows, floors, electricals; no furniture or object hallucinations.
- Implementation intent from docs: Repaint and refresh (as hinted by Estimate_40_26-10-2025.pdf and DOC-20251027-*.pdf), with color updates the key visual change.

You can change any palette codes to match the actual estimate once confirmed.
