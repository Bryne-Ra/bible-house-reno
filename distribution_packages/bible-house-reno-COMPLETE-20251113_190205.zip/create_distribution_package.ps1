# Bible House Reno - Distribution Package Creator (Windows PowerShell)
# Creates ZIP files ready for email or web deployment

$ErrorActionPreference = "Stop"

$ProjectDir = "C:\Users\LENOVO\Downloads\bible house reno"
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$OutputDir = Join-Path $ProjectDir "distribution_packages"

Write-Host "📦 Creating distribution packages for Bible House Reno..." -ForegroundColor Cyan
Write-Host ""

# Create output directory
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null

# Package 1: Email Distribution
Write-Host "Creating EMAIL package..." -ForegroundColor Yellow
$EmailZip = Join-Path $OutputDir "bible-house-reno-EMAIL-$Timestamp.zip"

$FilesToZip = @(
    "START_HERE.html",
    "presentation\index.html",
    "presentation\comparison.html",
    "presentation\floorplan.drawio",
    "presentation\palettes.svg",
    "IMG-20251103-WA0013.jpg",
    "IMG-20251103-WA0014.jpg",
    "IMG-20251103-WA0015.jpg",
    "IMG-20251103-WA0016.jpg",
    "IMG-20251103-WA0017.jpg",
    "IMG-20251103-WA0018.jpg",
    "IMG-20251103-WA0019.jpg",
    "IMG-20251103-WA0020.jpg",
    "IMG-20251103-WA0021.jpg",
    "IMG-20251103-WA0022.jpg",
    "IMG-20251103-WA0023.jpg",
    "IMG-20251103-WA0024.jpg",
    "README.md",
    "DISTRIBUTION_GUIDE.md",
    "ai_prompts.yaml"
)

Push-Location $ProjectDir
Compress-Archive -Path $FilesToZip -DestinationPath $EmailZip -Force
Pop-Location

$EmailSize = (Get-Item $EmailZip).Length / 1MB
Write-Host "✅ Email package created: $(Split-Path $EmailZip -Leaf)" -ForegroundColor Green
Write-Host "   Size: $([math]::Round($EmailSize, 2)) MB" -ForegroundColor Gray

# Package 2: Web Deployment
Write-Host ""
Write-Host "Creating WEB deployment package..." -ForegroundColor Yellow
$WebZip = Join-Path $OutputDir "bible-house-reno-WEB-$Timestamp.zip"

$WebFiles = @(
    "presentation",
    "START_HERE.html"
) + (Get-ChildItem "$ProjectDir\IMG-20251103-WA*.jpg" | Select-Object -ExpandProperty Name)

Push-Location $ProjectDir
Compress-Archive -Path $WebFiles -DestinationPath $WebZip -Force
Pop-Location

$WebSize = (Get-Item $WebZip).Length / 1MB
Write-Host "✅ Web package created: $(Split-Path $WebZip -Leaf)" -ForegroundColor Green
Write-Host "   Size: $([math]::Round($WebSize, 2)) MB" -ForegroundColor Gray

# Create README for recipients
Write-Host ""
Write-Host "Creating README for team..." -ForegroundColor Yellow

$TeamReadme = @"
========================================
BIBLE HOUSE RENOVATION - INTERACTIVE PRESENTATION
Estimate #40 | R 95,600 | 26 October 2025
========================================

WHAT'S INCLUDED:
- Interactive web presentations (HTML)
- 12 room photos
- 3 professional color palettes
- Floor plan diagram
- AI repaint prompts

HOW TO USE:
1. Extract this ZIP file to your computer
2. Double-click "START_HERE.html"
3. Your browser will open with a menu
4. Click any presentation to view

FEATURES:
✓ Works offline (no internet needed)
✓ View on any computer (Windows/Mac/Linux)
✓ Interactive color palette comparisons
✓ Copy-paste ready AI prompts
✓ Professional floor plan diagram

PRESENTATIONS INCLUDED:
1. Main Gallery - All rooms with color options
2. Comparison Tool - Before/after template
3. Floor Plan - Renovation scope diagram
4. Color Palettes - Professional swatches

TECHNICAL REQUIREMENTS:
- Any modern web browser (Chrome, Firefox, Edge, Safari)
- No installation needed
- No plugins required

FOR QUESTIONS:
Contact the project creator or refer to README.md

---
Created with VS Code + Live Server + AI Tools
Bible House Reno Interactive Presentation System
"@

$TeamReadme | Out-File -FilePath (Join-Path $OutputDir "README_FOR_TEAM.txt") -Encoding UTF8
Write-Host "✅ README created: README_FOR_TEAM.txt" -ForegroundColor Green

# Create web deployment instructions
$WebInstructions = @"
========================================
WEB DEPLOYMENT INSTRUCTIONS
Bible House Reno Presentation
========================================

OPTION 1: NETLIFY (EASIEST)
----------------------------
1. Go to https://app.netlify.com/drop
2. Drag the extracted folder onto the page
3. Get instant URL (e.g., https://random-name.netlify.app)
4. Share URL with team
5. (Optional) Set custom domain in settings

OPTION 2: GITHUB PAGES
----------------------
1. Create GitHub repository
2. Upload files to repository
3. Go to Settings > Pages
4. Select branch: main, folder: / (root)
5. Access at: https://yourusername.github.io/repo-name

OPTION 3: VERCEL
----------------
1. Install Vercel CLI: npm install -g vercel
2. Navigate to extracted folder
3. Run: vercel
4. Follow prompts
5. Get URL: https://project-name.vercel.app

OPTION 4: GOOGLE DRIVE / DROPBOX
---------------------------------
1. Upload folder to cloud storage
2. Set sharing to "Anyone with link"
3. Share folder link with team
4. Team opens index.html from shared folder
   ⚠️ Note: Some interactive features may not work

RECOMMENDED: Netlify or Vercel for best experience
"@

$WebInstructions | Out-File -FilePath (Join-Path $OutputDir "WEB_DEPLOYMENT_INSTRUCTIONS.txt") -Encoding UTF8
Write-Host "✅ Web deployment instructions created" -ForegroundColor Green

# Summary
Write-Host ""
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host "📦 PACKAGING COMPLETE!" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Created in: $OutputDir" -ForegroundColor White
Write-Host ""
Write-Host "FILES CREATED:" -ForegroundColor Yellow
Write-Host "  1. $(Split-Path $EmailZip -Leaf) - For email distribution" -ForegroundColor White
Write-Host "  2. $(Split-Path $WebZip -Leaf) - For web hosting" -ForegroundColor White
Write-Host "  3. README_FOR_TEAM.txt - Instructions for recipients" -ForegroundColor White
Write-Host "  4. WEB_DEPLOYMENT_INSTRUCTIONS.txt - Hosting guide" -ForegroundColor White
Write-Host ""
Write-Host "NEXT STEPS:" -ForegroundColor Yellow
Write-Host "  📧 Email: Attach $(Split-Path $EmailZip -Leaf) to email" -ForegroundColor White
Write-Host "  🌐 Web: Deploy $(Split-Path $WebZip -Leaf) to Netlify/Vercel" -ForegroundColor White
Write-Host ""
Write-Host "WINDOWS PATH:" -ForegroundColor Yellow
Write-Host "  $OutputDir" -ForegroundColor White
Write-Host ""
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host ""

# Open folder
Start-Process explorer.exe $OutputDir
Write-Host "Opening distribution folder..." -ForegroundColor Cyan
